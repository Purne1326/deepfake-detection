import streamlit as st

# ── Permission matrix ──────────────────────────────────────────────────────────
PERMISSIONS: dict[str, set[str]] = {
    "admin": {
        "view",
        "approve",
        "reject",
        "retry",
        "manage_accounts",
        "force_action",
    },
    "reviewer": {
        "view",
        "approve",
        "reject",
        "retry",
    },
}


def get_role() -> str | None:
    """Return the current user's role from session state, or None."""
    return st.session_state.get("role")


def can(action: str) -> bool:
    """Return True if the currently logged-in user has permission for *action*."""
    role = get_role()
    if role is None:
        return False
    return action in PERMISSIONS.get(role, set())


def require(action: str):
    """Hard-stop guard. Renders an error and raises st.stop() if denied."""
    if not can(action):
        st.error(f"⛔ Access denied — requires permission: `{action}`")
        st.stop()
