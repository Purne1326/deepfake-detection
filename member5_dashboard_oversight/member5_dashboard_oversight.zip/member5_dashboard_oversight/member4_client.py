import os
import requests
from typing import Any

# ── Config ─────────────────────────────────────────────────────────────────────

def _base_url() -> str:
    return os.environ.get("MEMBER4_BASE_URL", "http://localhost:8004").rstrip("/")


def _headers() -> dict:
    api_key = os.environ.get("MEMBER4_API_KEY", "")
    h = {"Content-Type": "application/json"}
    if api_key:
        h["X-API-Key"] = api_key
    return h


def _post(path: str, payload: dict) -> dict[str, Any]:
    url = f"{_base_url()}{path}"
    try:
        resp = requests.post(url, json=payload, headers=_headers(), timeout=10)
        resp.raise_for_status()
        return {"success": True, "data": resp.json()}
    except requests.exceptions.Timeout:
        return {"success": False, "error": "Request timed out"}
    except requests.exceptions.HTTPError as e:
        return {"success": False, "error": str(e), "status_code": e.response.status_code}
    except requests.exceptions.RequestException as e:
        return {"success": False, "error": str(e)}


# ── Public API ─────────────────────────────────────────────────────────────────

def approve_case(case_id: str, reviewer: str, notes: str = "") -> dict[str, Any]:
    """Send manual approval for a case to Member 4."""
    return _post(
        "/internal/manual-approve",
        {"case_id": case_id, "reviewer": reviewer, "notes": notes},
    )


def reject_case(case_id: str, reviewer: str, reason: str = "") -> dict[str, Any]:
    """Send manual rejection for a case to Member 4."""
    return _post(
        "/internal/manual-reject",
        {"case_id": case_id, "reviewer": reviewer, "reason": reason},
    )


def retry_case(case_id: str, reviewer: str) -> dict[str, Any]:
    """Request a retry for a failed/error case."""
    return _post(
        "/internal/retry",
        {"case_id": case_id, "requested_by": reviewer},
    )


def health_check() -> dict[str, Any]:
    """Check Member 4 API health."""
    url = f"{_base_url()}/health"
    try:
        resp = requests.get(url, headers=_headers(), timeout=5)
        resp.raise_for_status()
        return {"success": True, "data": resp.json()}
    except requests.exceptions.Timeout:
        return {"success": False, "error": "Health check timed out"}
    except requests.exceptions.RequestException as e:
        return {"success": False, "error": str(e)}
