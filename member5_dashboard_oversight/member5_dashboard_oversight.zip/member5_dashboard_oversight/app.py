import os
import streamlit as st
from authentication import render_login_page, is_authenticated
from dashboard_routes import (
    render_overview,
    render_alerts,
    render_case_details,
    render_reports,
    render_audit_logs,
    render_admin,
)

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Oversight Dashboard",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS theme injection ─────────────────────────────────────────────────────────
st.markdown(
    """
    <style>
    html, body, [data-testid="stAppViewContainer"] {
        background-color: #0d0f14;
        color: #c9d1d9;
        font-family: 'IBM Plex Mono', monospace;
    }
    [data-testid="stSidebar"] {
        background-color: #161b22;
        border-right: 1px solid #21262d;
    }
    .stButton > button {
        background-color: #21262d;
        color: #c9d1d9;
        border: 1px solid #30363d;
        border-radius: 6px;
    }
    .stButton > button:hover {
        background-color: #30363d;
        border-color: #58a6ff;
        color: #58a6ff;
    }
    .stTextInput > div > input,
    .stSelectbox > div > div {
        background-color: #161b22;
        color: #c9d1d9;
        border: 1px solid #30363d;
    }
    .stMetric { background-color: #161b22; border-radius: 8px; padding: 12px; }
    hr { border-color: #21262d; }
    </style>
    """,
    unsafe_allow_html=True,
)

# ── Auth gate ───────────────────────────────────────────────────────────────────
if not is_authenticated():
    render_login_page()
    st.stop()

# ── Sidebar nav ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🛡️ Oversight Dashboard")
    st.markdown("---")

    role = st.session_state.get("role", "reviewer")
    user = st.session_state.get("username", "")
    st.markdown(f"👤 **{user}** `{role}`")
    st.markdown("---")

    pages = ["Overview", "Alerts", "Case Details", "Reports", "Audit Logs"]
    if role == "admin":
        pages.append("Admin")

    page = st.radio("Navigate", pages, label_visibility="collapsed")

    st.markdown("---")
    if st.button("🚪 Logout"):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()

# ── Route to page renderers ─────────────────────────────────────────────────────
if page == "Overview":
    render_overview()
elif page == "Alerts":
    render_alerts()
elif page == "Case Details":
    render_case_details()
elif page == "Reports":
    render_reports()
elif page == "Audit Logs":
    render_audit_logs()
elif page == "Admin":
    render_admin()
