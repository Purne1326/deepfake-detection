"""
All 6 page renderers for the Oversight Dashboard.
Falls back to demo data when the PostgreSQL DB is unavailable.
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta
import random

import pandas as pd
import streamlit as st

from access_control import can, require
from data_access import (
    FORBIDDEN_FIELDS,
    get_case_stats,
    get_cases,
    get_case_by_id,
    get_audit_logs,
    load_evidence_report,
)
from member4_client import approve_case, reject_case, retry_case, health_check

# ── Demo-data helpers (used when DB is offline) ────────────────────────────────

_STATUSES  = ["pending", "approved", "rejected", "error"]
_RISKS     = ["high", "medium", "low"]
_PLATFORMS = ["twitter", "reddit", "telegram", "discord"]


def _demo_cases(n: int = 30) -> list[dict]:
    random.seed(42)
    cases = []
    for i in range(n):
        cases.append(
            {
                "case_id":                  f"CASE-{1000 + i}",
                "platform":                 random.choice(_PLATFORMS),
                "post_id":                  f"post_{i:04d}",
                "post_url":                 f"https://example.com/post/{i}",
                "status":                   random.choice(_STATUSES),
                "risk_level":               random.choice(_RISKS),
                "match_confidence":         round(random.uniform(0.5, 1.0), 3),
                "match_distance":           round(random.uniform(0.0, 0.5), 3),
                "deepfake_score":           round(random.uniform(0.0, 1.0), 3),
                "nudity_score":             round(random.uniform(0.0, 1.0), 3),
                "compliance_reason":        "threshold_exceeded",
                "allow_auto_action":        random.choice([True, False]),
                "manual_review_required":   random.choice([True, False]),
                "platform_action_status":   random.choice(["pending", "done", "failed"]),
                "platform_action_response": "{}",
                "evidence_report_path":     f"report_{i}.json",
                "created_at":               datetime.utcnow() - timedelta(hours=i * 3),
                "updated_at":               datetime.utcnow() - timedelta(hours=i),
            }
        )
    return cases


def _demo_stats() -> dict:
    return {
        "total": 120, "pending": 18, "approved": 74, "rejected": 22, "error": 6,
        "high_risk": 31, "medium_risk": 55, "low_risk": 34, "needs_review": 18,
    }


def _demo_logs(n: int = 40) -> list[dict]:
    random.seed(7)
    actions = ["auto_approved", "manual_approved", "manual_rejected", "retry_requested", "case_created"]
    logs = []
    for i in range(n):
        logs.append(
            {
                "id":          i + 1,
                "case_id":     f"CASE-{1000 + (i % 30)}",
                "platform":    random.choice(_PLATFORMS),
                "action_type": random.choice(actions),
                "status":      random.choice(["success", "failed"]),
                "details":     json.dumps({"note": f"demo log {i}"}),
                "created_at":  datetime.utcnow() - timedelta(minutes=i * 17),
            }
        )
    return logs


def _safe_get_stats() -> dict:
    try:
        return get_case_stats()
    except Exception:
        return _demo_stats()


def _safe_get_cases(**kw) -> list[dict]:
    try:
        return get_cases(**kw)
    except Exception:
        cases = _demo_cases()
        if kw.get("status"):
            cases = [c for c in cases if c["status"] == kw["status"]]
        if kw.get("risk_level"):
            cases = [c for c in cases if c["risk_level"] == kw["risk_level"]]
        return cases[: kw.get("limit", 100)]


def _safe_get_logs(**kw) -> list[dict]:
    try:
        return get_audit_logs(**kw)
    except Exception:
        logs = _demo_logs()
        if kw.get("case_id"):
            logs = [l for l in logs if l["case_id"] == kw["case_id"]]
        return logs


# ── 1. Overview ────────────────────────────────────────────────────────────────

def render_overview():
    require("view")
    st.markdown("## 📊 Overview")
    st.markdown("---")

    stats = _safe_get_stats()

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Total Cases",     stats.get("total", 0))
    c2.metric("⏳ Pending",      stats.get("pending", 0))
    c3.metric("✅ Approved",     stats.get("approved", 0))
    c4.metric("❌ Rejected",     stats.get("rejected", 0))
    c5.metric("⚠️ Needs Review", stats.get("needs_review", 0))

    st.markdown("---")

    col_a, col_b = st.columns(2)

    with col_a:
        st.markdown("#### Risk Level Breakdown")
        risk_df = pd.DataFrame(
            {
                "Risk":  ["High 🔴", "Medium 🟡", "Low 🟢"],
                "Count": [
                    stats.get("high_risk", 0),
                    stats.get("medium_risk", 0),
                    stats.get("low_risk", 0),
                ],
            }
        )
        st.bar_chart(risk_df.set_index("Risk"))

    with col_b:
        st.markdown("#### Status Distribution")
        status_df = pd.DataFrame(
            {
                "Status": ["Pending", "Approved", "Rejected", "Error"],
                "Count":  [
                    stats.get("pending", 0),
                    stats.get("approved", 0),
                    stats.get("rejected", 0),
                    stats.get("error", 0),
                ],
            }
        )
        st.bar_chart(status_df.set_index("Status"))

    st.markdown("---")
    st.markdown("#### 🕐 Recent Audit Activity")
    logs = _safe_get_logs(limit=10)
    if logs:
        df = pd.DataFrame(logs)[["created_at", "case_id", "platform", "action_type", "status"]]
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No recent activity.")


# ── 2. Alerts ─────────────────────────────────────────────────────────────────

def render_alerts():
    require("view")
    st.markdown("## 🚨 Alerts — Manual Review Queue")
    st.markdown("---")

    col1, col2 = st.columns([1, 1])
    with col1:
        risk_filter = st.selectbox("Filter by risk", ["All", "high", "medium", "low"])
    with col2:
        limit = st.slider("Max cases shown", 5, 100, 25)

    kw: dict = {"status": "pending", "limit": limit}
    if risk_filter != "All":
        kw["risk_level"] = risk_filter

    cases = _safe_get_cases(**kw)

    if not cases:
        st.success("✅ No cases pending manual review.")
        return

    st.markdown(f"**{len(cases)} case(s) awaiting review**")
    st.markdown("---")

    for case in cases:
        cid        = case["case_id"]
        risk       = case.get("risk_level", "unknown")
        platform   = case.get("platform", "—")
        confidence = case.get("match_confidence", 0)
        deepfake   = case.get("deepfake_score", 0)
        nudity     = case.get("nudity_score", 0)

        risk_colour = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(risk, "⚪")

        with st.expander(f"{risk_colour} `{cid}` · {platform} · confidence {confidence:.2%}"):
            st.markdown(
                f"""
| Field | Value |
|---|---|
| **Platform** | {platform} |
| **Risk Level** | {risk} |
| **Match Confidence** | {confidence:.3f} |
| **Deepfake Score** | {deepfake:.3f} |
| **Nudity Score** | {nudity:.3f} |
| **Post URL** | {case.get('post_url', '—')} |
"""
            )

            if can("approve") or can("reject") or can("retry"):
                act_col1, act_col2, act_col3, _ = st.columns([1, 1, 1, 3])
                reviewer = st.session_state.get("username", "unknown")

                with act_col1:
                    if can("approve") and st.button("✅ Approve", key=f"approve_{cid}"):
                        result = approve_case(cid, reviewer)
                        if result["success"]:
                            st.success(f"Case {cid} approved.")
                        else:
                            st.error(f"Error: {result['error']}")

                with act_col2:
                    if can("reject") and st.button("❌ Reject", key=f"reject_{cid}"):
                        result = reject_case(cid, reviewer, reason="Manual rejection")
                        if result["success"]:
                            st.warning(f"Case {cid} rejected.")
                        else:
                            st.error(f"Error: {result['error']}")

                with act_col3:
                    if can("retry") and st.button("🔁 Retry", key=f"retry_{cid}"):
                        result = retry_case(cid, reviewer)
                        if result["success"]:
                            st.info(f"Case {cid} queued for retry.")
                        else:
                            st.error(f"Error: {result['error']}")
            else:
                st.warning("⛔ You do not have permission to take action on cases.")


# ── 3. Case Details ────────────────────────────────────────────────────────────

def render_case_details():
    require("view")
    st.markdown("## 🔍 Case Details")
    st.markdown("---")

    case_id = st.text_input("Enter Case ID", placeholder="CASE-1000")

    if not case_id:
        st.info("Enter a case ID above to load the full investigation view.")
        return

    try:
        case = get_case_by_id(case_id)
    except Exception:
        demo = {c["case_id"]: c for c in _demo_cases()}
        case = demo.get(case_id)

    if not case:
        st.error(f"Case `{case_id}` not found.")
        return

    # Section 1 — Identity
    st.markdown("### 1 · Case Identity")
    col1, col2, col3 = st.columns(3)
    col1.metric("Case ID",  case.get("case_id"))
    col2.metric("Platform", case.get("platform", "—"))
    col3.metric("Status",   case.get("status", "—").upper())

    # Section 2 — Risk & Scores
    st.markdown("### 2 · Risk & Detection Scores")
    s1, s2, s3, s4 = st.columns(4)
    s1.metric("Risk Level",       case.get("risk_level", "—").upper())
    s2.metric("Match Confidence", f"{case.get('match_confidence', 0):.3f}")
    s3.metric("Deepfake Score",   f"{case.get('deepfake_score', 0):.3f}")
    s4.metric("Nudity Score",     f"{case.get('nudity_score', 0):.3f}")

    # Section 3 — Compliance
    st.markdown("### 3 · Compliance Decision")
    st.json(
        {
            "compliance_reason":      case.get("compliance_reason"),
            "allow_auto_action":      case.get("allow_auto_action"),
            "manual_review_required": case.get("manual_review_required"),
        }
    )

    # Section 4 — Platform Action
    st.markdown("### 4 · Platform Action")
    st.json(
        {
            "platform_action_status":   case.get("platform_action_status"),
            "platform_action_response": case.get("platform_action_response"),
            "post_url":                 case.get("post_url"),
        }
    )

    # Section 5 — Thresholds Snapshot
    st.markdown("### 5 · Thresholds Snapshot")
    thresholds = case.get("thresholds_snapshot")
    if thresholds:
        try:
            st.json(json.loads(thresholds) if isinstance(thresholds, str) else thresholds)
        except Exception:
            st.code(str(thresholds))
    else:
        st.info("No threshold snapshot available.")

    # Section 6 — Evidence Packet
    st.markdown("### 6 · Evidence Packet")
    report_path = case.get("evidence_report_path")
    if report_path:
        try:
            evidence = load_evidence_report(report_path)
            if evidence:
                st.json(evidence)
                st.download_button(
                    "⬇️ Download Evidence JSON",
                    data=json.dumps(evidence, indent=2, default=str),
                    file_name=f"evidence_{case_id}.json",
                    mime="application/json",
                )
            else:
                st.warning("Evidence file not found on disk.")
        except Exception as e:
            st.error(f"Could not load evidence: {e}")
    else:
        st.info("No evidence report path recorded.")

    # Section 7 — Audit Timeline
    st.markdown("### 7 · Audit Timeline")
    logs = _safe_get_logs(case_id=case_id, limit=50)
    if logs:
        df = pd.DataFrame(logs)[["created_at", "action_type", "status", "details"]]
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No audit entries for this case.")


# ── 4. Reports ────────────────────────────────────────────────────────────────

def render_reports():
    require("view")
    st.markdown("## 📂 Reports — Evidence Library")
    st.markdown("---")

    col1, col2, col3 = st.columns(3)
    with col1:
        status_filter = st.selectbox("Status", ["All", "pending", "approved", "rejected", "error"])
    with col2:
        risk_filter = st.selectbox("Risk Level", ["All", "high", "medium", "low"])
    with col3:
        limit = st.slider("Max results", 10, 200, 50)

    kw: dict = {"limit": limit}
    if status_filter != "All":
        kw["status"] = status_filter
    if risk_filter != "All":
        kw["risk_level"] = risk_filter

    cases = _safe_get_cases(**kw)

    if not cases:
        st.info("No cases match the selected filters.")
        return

    df = pd.DataFrame(cases)
    display_cols = [
        c for c in [
            "case_id", "platform", "status", "risk_level",
            "match_confidence", "deepfake_score", "nudity_score",
            "evidence_report_path", "created_at",
        ]
        if c in df.columns
    ]

    st.markdown(f"**{len(cases)} report(s) found**")
    st.dataframe(df[display_cols], use_container_width=True, hide_index=True)

    csv = df[display_cols].to_csv(index=False)
    st.download_button(
        "⬇️ Download as CSV",
        data=csv,
        file_name="reports_export.csv",
        mime="text/csv",
    )


# ── 5. Audit Logs ─────────────────────────────────────────────────────────────

def render_audit_logs():
    require("view")
    st.markdown("## 📋 Audit Logs")
    st.markdown("---")

    col1, col2, col3 = st.columns(3)
    with col1:
        case_id_filter = st.text_input("Filter by Case ID", placeholder="CASE-1000")
    with col2:
        action_filter = st.selectbox(
            "Action Type",
            ["All", "auto_approved", "manual_approved", "manual_rejected",
             "retry_requested", "case_created"],
        )
    with col3:
        limit = st.slider("Max entries", 10, 500, 100)

    kw: dict = {"limit": limit}
    if case_id_filter.strip():
        kw["case_id"] = case_id_filter.strip()
    if action_filter != "All":
        kw["action_type"] = action_filter

    logs = _safe_get_logs(**kw)

    if not logs:
        st.info("No audit log entries match the selected filters.")
        return

    df = pd.DataFrame(logs)
    display_cols = [
        c for c in
        ["id", "created_at", "case_id", "platform", "action_type", "status", "details"]
        if c in df.columns
    ]
    st.markdown(f"**{len(logs)} log entry/entries**")
    st.dataframe(df[display_cols], use_container_width=True, hide_index=True)

    csv = df[display_cols].to_csv(index=False)
    st.download_button(
        "⬇️ Download Logs as CSV",
        data=csv,
        file_name="audit_logs_export.csv",
        mime="text/csv",
    )


# ── 6. Admin ──────────────────────────────────────────────────────────────────

def render_admin():
    require("manage_accounts")
    st.markdown("## ⚙️ Admin Panel")
    st.markdown("---")

    # Section A — Member 4 Health
    st.markdown("### 🔌 Member 4 API Health")
    if st.button("Check Health"):
        result = health_check()
        if result["success"]:
            st.success(f"✅ Member 4 is healthy — {result['data']}")
        else:
            st.error(f"❌ Member 4 unreachable — {result['error']}")

    st.markdown("---")

    # Section B — Account overview
    st.markdown("### 👥 Team Accounts")
    from authentication import ACCOUNTS
    rows = [
        {"username": uname, "role": info["role"]}
        for uname, info in ACCOUNTS.items()
    ]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    st.markdown("---")

    # Section C — Force action (admin only)
    if can("force_action"):
        st.markdown("### ⚡ Force Action (Override)")
        fc1, fc2 = st.columns(2)
        with fc1:
            force_case_id = st.text_input("Case ID to force-action", key="force_cid")
            force_action  = st.selectbox("Action", ["approve", "reject", "retry"], key="force_act")
        with fc2:
            force_notes = st.text_area("Notes / reason", key="force_notes")

        if st.button("⚡ Execute Force Action"):
            reviewer = st.session_state.get("username", "admin")
            if force_action == "approve":
                result = approve_case(force_case_id, reviewer, notes=force_notes)
            elif force_action == "reject":
                result = reject_case(force_case_id, reviewer, reason=force_notes)
            else:
                result = retry_case(force_case_id, reviewer)

            if result["success"]:
                st.success(f"✅ Force-{force_action} sent for `{force_case_id}`")
            else:
                st.error(f"❌ {result['error']}")

    st.markdown("---")

    # Section D — System config display
    st.markdown("### 🔧 System Configuration")
    import os
    st.json(
        {
            "DATABASE_URL":     os.environ.get("DATABASE_URL", "(not set — using default)"),
            "MEMBER4_BASE_URL": os.environ.get("MEMBER4_BASE_URL", "http://localhost:8004"),
            "REPORTS_DIR":      os.environ.get("REPORTS_DIR", "reports"),
        }
    )
