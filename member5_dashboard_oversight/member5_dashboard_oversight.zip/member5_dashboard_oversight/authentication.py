import os
import hashlib
import hmac
import streamlit as st

# ── Password hashing (PBKDF2-SHA256) ──────────────────────────────────────────

def _hash_password(password: str, salt: bytes = None, iterations: int = 260000) -> str:
    """Hash a password using PBKDF2-SHA256. Returns 'iterations:hex_salt:hex_hash'."""
    if salt is None:
        salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
    return f"{iterations}:{salt.hex()}:{dk.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    """Verify a plaintext password against a stored PBKDF2-SHA256 hash."""
    try:
        iterations_str, salt_hex, hash_hex = stored_hash.split(":")
        iterations = int(iterations_str)
        salt = bytes.fromhex(salt_hex)
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False


# ── Pre-computed default hashes ────────────────────────────────────────────────
_DEFAULTS = {
    "admin":     ("admin",     "Admin@2025!",  "admin"),
    "reviewer1": ("reviewer1", "Review@001!",  "reviewer"),
    "reviewer2": ("reviewer2", "Review@002!",  "reviewer"),
    "reviewer3": ("reviewer3", "Review@003!",  "reviewer"),
    "reviewer4": ("reviewer4", "Review@004!",  "reviewer"),
}

def _build_accounts() -> dict:
    """
    Build accounts dict from environment variables.
    Falls back to hashing the default plaintext passwords at startup.
    """
    accounts = {}
    env_map = {
        "admin":     ("ADMIN_USER",     "ADMIN_HASH"),
        "reviewer1": ("REVIEWER1_USER", "REVIEWER1_HASH"),
        "reviewer2": ("REVIEWER2_USER", "REVIEWER2_HASH"),
        "reviewer3": ("REVIEWER3_USER", "REVIEWER3_HASH"),
        "reviewer4": ("REVIEWER4_USER", "REVIEWER4_HASH"),
    }
    for key, (user_env, hash_env) in env_map.items():
        _, default_pass, role = _DEFAULTS[key]
        username = os.environ.get(user_env, key)
        stored   = os.environ.get(hash_env, _hash_password(default_pass))
        accounts[username] = {"hash": stored, "role": role}
    return accounts


# Built once at module load
ACCOUNTS: dict = _build_accounts()


# ── Session helpers ────────────────────────────────────────────────────────────

def is_authenticated() -> bool:
    return st.session_state.get("authenticated", False)


def logout():
    for key in list(st.session_state.keys()):
        del st.session_state[key]


# ── Login page renderer ────────────────────────────────────────────────────────

def render_login_page():
    st.markdown(
        "<h2 style='color:#58a6ff;text-align:center;margin-top:80px'>🛡️ Oversight Dashboard</h2>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<p style='color:#8b949e;text-align:center;margin-bottom:32px'>Human Review & Governance Layer</p>",
        unsafe_allow_html=True,
    )

    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        with st.form("login_form"):
            st.markdown("#### Sign In")
            username = st.text_input("Username", placeholder="username")
            password = st.text_input("Password", type="password", placeholder="••••••••")
            submitted = st.form_submit_button("Login", use_container_width=True)

            if submitted:
                account = ACCOUNTS.get(username)
                if account and verify_password(password, account["hash"]):
                    st.session_state["authenticated"] = True
                    st.session_state["username"] = username
                    st.session_state["role"] = account["role"]
                    st.rerun()
                else:
                    st.error("Invalid username or password.")
