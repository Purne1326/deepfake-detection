"""
10 unit tests for data safety + RBAC.

TestDataSafety    (4 tests) — forbidden biometric fields are stripped
TestAccessControl (6 tests) — reviewer/admin RBAC + unauthenticated blocked
"""
import sys
import os
import types

# ── Stub streamlit ─────────────────────────────────────────────────────────────
_st_stub = types.ModuleType("streamlit")
_st_stub.session_state = {}
_st_stub.error = lambda *a, **kw: None
_st_stub.stop  = lambda: (_ for _ in ()).throw(SystemExit(0))
sys.modules.setdefault("streamlit", _st_stub)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from data_access import FORBIDDEN_FIELDS, _strip_forbidden
from access_control import PERMISSIONS, can


class TestDataSafety:
    """Biometric / embedding fields must never reach the UI."""

    def test_forbidden_fields_constant_is_non_empty(self):
        assert len(FORBIDDEN_FIELDS) > 0

    def test_face_embedding_stripped(self):
        row = {"case_id": "CASE-1", "face_embedding": b"\x00\x01", "status": "pending"}
        result = _strip_forbidden(row)
        assert "face_embedding" not in result

    def test_all_forbidden_fields_stripped(self):
        row = {field: "SENSITIVE" for field in FORBIDDEN_FIELDS}
        row["case_id"] = "CASE-2"
        result = _strip_forbidden(row)
        for field in FORBIDDEN_FIELDS:
            assert field not in result

    def test_allowed_fields_pass_through(self):
        row = {
            "case_id":          "CASE-3",
            "platform":         "twitter",
            "match_confidence": 0.95,
            "face_embedding":   "should_be_removed",
        }
        result = _strip_forbidden(row)
        assert result["case_id"]          == "CASE-3"
        assert result["platform"]         == "twitter"
        assert result["match_confidence"] == 0.95
        assert "face_embedding" not in result


class TestAccessControl:
    """RBAC permission matrix checks."""

    def setup_method(self):
        _st_stub.session_state.clear()

    def test_reviewer_can_view(self):
        _st_stub.session_state["role"] = "reviewer"
        assert can("view") is True

    def test_reviewer_can_approve(self):
        _st_stub.session_state["role"] = "reviewer"
        assert can("approve") is True

    def test_reviewer_cannot_manage_accounts(self):
        _st_stub.session_state["role"] = "reviewer"
        assert can("manage_accounts") is False

    def test_reviewer_cannot_force_action(self):
        _st_stub.session_state["role"] = "reviewer"
        assert can("force_action") is False

    def test_admin_can_manage_accounts(self):
        _st_stub.session_state["role"] = "admin"
        assert can("manage_accounts") is True

    def test_unauthenticated_cannot_view(self):
        assert can("view") is False
