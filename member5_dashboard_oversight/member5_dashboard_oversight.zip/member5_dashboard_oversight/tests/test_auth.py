"""
11 unit tests for authentication.py

TestVerify  (7 tests) — password hashing & verification
TestSession (4 tests) — session state helpers
"""
import sys
import os
import types

# ── Stub streamlit so tests run without a Streamlit server ────────────────────
_st_stub = types.ModuleType("streamlit")
_st_stub.session_state = {}
_st_stub.error = lambda *a, **kw: None
_st_stub.stop  = lambda: None
sys.modules.setdefault("streamlit", _st_stub)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from authentication import _hash_password, verify_password, ACCOUNTS, is_authenticated, logout


class TestVerify:
    """Password hash / verify round-trips."""

    def test_correct_password_returns_true(self):
        h = _hash_password("MySecret1!")
        assert verify_password("MySecret1!", h) is True

    def test_wrong_password_returns_false(self):
        h = _hash_password("CorrectHorse")
        assert verify_password("WrongBattery", h) is False

    def test_empty_password_does_not_match_non_empty_hash(self):
        h = _hash_password("SomePa$$word")
        assert verify_password("", h) is False

    def test_five_accounts_exist(self):
        assert len(ACCOUNTS) == 5

    def test_exactly_one_admin(self):
        admins = [u for u, info in ACCOUNTS.items() if info["role"] == "admin"]
        assert len(admins) == 1

    def test_exactly_four_reviewers(self):
        reviewers = [u for u, info in ACCOUNTS.items() if info["role"] == "reviewer"]
        assert len(reviewers) == 4

    def test_unknown_user_not_in_accounts(self):
        assert "hacker" not in ACCOUNTS

    def test_default_admin_credentials_verify(self):
        account = ACCOUNTS.get("admin")
        assert account is not None
        assert verify_password("Admin@2025!", account["hash"]) is True

    def test_default_reviewer1_credentials_verify(self):
        account = ACCOUNTS.get("reviewer1")
        assert account is not None
        assert verify_password("Review@001!", account["hash"]) is True


class TestSession:
    """st.session_state helpers."""

    def setup_method(self):
        """Reset session state before each test."""
        _st_stub.session_state.clear()

    def test_not_authenticated_when_session_empty(self):
        assert is_authenticated() is False

    def test_authenticated_after_flag_set(self):
        _st_stub.session_state["authenticated"] = True
        assert is_authenticated() is True

    def test_logout_clears_session(self):
        _st_stub.session_state["authenticated"] = True
        _st_stub.session_state["username"] = "admin"
        _st_stub.session_state["role"] = "admin"
        logout()
        assert _st_stub.session_state == {}

    def test_not_authenticated_after_logout(self):
        _st_stub.session_state["authenticated"] = True
        logout()
        assert is_authenticated() is False
